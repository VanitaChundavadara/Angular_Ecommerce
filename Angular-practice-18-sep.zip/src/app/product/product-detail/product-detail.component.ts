import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
} from '@angular/core';
import Product from 'src/app/model/Product';
import { ProductComponent } from '../product.component';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
})
export class ProductDetailComponent {
  @Input()
  visible: boolean = false;
  // @Input()
  // productlist: any;
  @Input()
  // selectProduct: any;
  @Output() cardclick = new EventEmitter<any>();
  onCardClick() {
    this.cardclick.emit(false);
  }

  ngOnChanges() {
    // console.log('productlist',this.productlist);
  }
  @Input()
  productlistComp: ProductComponent = undefined;
  product: Product;
  ngOnInit() {
    this.product = this.productlistComp.selectedProduct;
  }
  Product(){
    console.log("product",this.product);
    
  }
}
